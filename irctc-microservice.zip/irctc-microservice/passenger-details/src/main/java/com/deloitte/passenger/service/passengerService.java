package com.deloitte.passenger.service;

import java.util.List;

import com.deloitte.passenger.entity.passengers;

public interface passengerService
{
	public List<passengers> getAllpassengers();
	public List<passengers> getpassengerByPid(Integer id);
}
