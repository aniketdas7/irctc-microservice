package com.deloitte.passenger.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deloitte.passenger.entity.passengers;

public interface passengerRepository extends JpaRepository<passengers, Integer>
{

	public List<passengers> findByPid(Integer passenger_id);
}
