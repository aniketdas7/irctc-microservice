package com.deloitte.passenger.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.passenger.entity.passengers;
import com.deloitte.passenger.repo.passengerRepository;

@Service
public class passengerServiceImpl implements passengerService {

	@Autowired
	passengerRepository prepo;

	@Override
	public List<passengers> getAllpassengers()
	{
		
		return prepo.findAll();
	}

	@Override
	public List<passengers> getpassengerByPid(Integer id) {
		
		return prepo.findByPid(id);
	}
}