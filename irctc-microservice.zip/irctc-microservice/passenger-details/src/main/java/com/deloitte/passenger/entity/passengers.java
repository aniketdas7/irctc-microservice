package com.deloitte.passenger.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "passengers-lists")
public class passengers {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer sno;
	private Integer pnrno;
	private String FirstName;
	private String LastName;
	private String Gender;
	private Integer Age;
	private Integer pid;
	public passengers() {
		super();
		// TODO Auto-generated constructor stub
	}
	public passengers(Integer sno, Integer pnrno, String firstName, String lastName, String gender, Integer age,
			Integer pid) {
		super();
		this.sno = sno;
		this.pnrno = pnrno;
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
		Age = age;
		this.pid = pid;
	}
	public Integer getSno() {
		return sno;
	}
	public void setSno(Integer sno) {
		this.sno = sno;
	}
	public Integer getPnrno() {
		return pnrno;
	}
	public void setPnrno(Integer pnrno) {
		this.pnrno = pnrno;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public Integer getAge() {
		return Age;
	}
	public void setAge(Integer age) {
		Age = age;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	
		


	
	

}
