package com.deloitte.irctc.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name= "trains")
public class trains {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer pid;
	private Integer pnrNo;
	private Integer TrainNo;
	private String TrainName;
	
	
	public trains() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public trains(Integer pid, Integer pnrNo, Integer trainNo, String trainName) {
		super();
		this.pid = pid;
		this.pnrNo = pnrNo;
		TrainNo = trainNo;
		TrainName = trainName;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public Integer getPnrNo() {
		return pnrNo;
	}
	public void setPnrNo(Integer pnrNo) {
		this.pnrNo = pnrNo;
	}
	public Integer getTrainNo() {
		return TrainNo;
	}
	public void setTrainNo(Integer trainNo) {
		TrainNo = trainNo;
	}
	public String getTrainName() {
		return TrainName;
	}
	public void setTrainName(String trainName) {
		TrainName = trainName;
	}
	
	
	
}
