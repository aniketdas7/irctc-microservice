package com.deloitte.irctc.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.deloitte.irctc.entity.trains;


public interface trainsRepository extends JpaRepository<trains, Integer>{
	
	public List<trains> findByPid(Integer p_Id);
}