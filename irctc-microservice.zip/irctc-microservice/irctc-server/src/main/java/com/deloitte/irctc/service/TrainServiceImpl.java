package com.deloitte.irctc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.irctc.entity.trains;
import com.deloitte.irctc.repo.trainsRepository;


@Service
public class TrainServiceImpl implements TrainService
{
	@Autowired
	trainsRepository trepo;

	@Override
	public List<trains> getTrains() {
		
		return trepo.findAll();
		}

	@Override
	public List<trains> getTrain(Integer id) {
		// TODO Auto-generated method stub
		return trepo.findByPid(id);
	}
	
}
