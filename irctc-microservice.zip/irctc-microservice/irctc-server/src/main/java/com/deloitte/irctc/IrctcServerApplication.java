package com.deloitte.irctc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class IrctcServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(IrctcServerApplication.class, args);
	}

}
