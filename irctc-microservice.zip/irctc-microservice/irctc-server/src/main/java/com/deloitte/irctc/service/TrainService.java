package com.deloitte.irctc.service;

import java.util.List;

import com.deloitte.irctc.entity.trains;

public interface TrainService {
	
	public List<trains> getTrains();
	public List<trains> getTrain(Integer id);

}