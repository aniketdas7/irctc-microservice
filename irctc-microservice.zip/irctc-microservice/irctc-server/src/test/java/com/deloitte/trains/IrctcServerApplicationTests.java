package com.deloitte.trains;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IrctcServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
